-- ================================================
-- ПРОВЕРОЧНЫЕ ЗАПРОСЫ К БД fitnes.db
-- Текущая дата: 2026-10-03
-- ================================================

PRAGMA foreign_keys = ON;

-- 1. Кто сейчас имеет активный абонемент
SELECT
    m.member_id,
    m.first_name || ' ' || m.last_name AS member_name,
    p.payment_type,
    p.period_start,
    p.period_end,
    p.amount
FROM members m
JOIN payments p ON m.member_id = p.member_id
WHERE date('2026-10-03') BETWEEN p.period_start AND p.period_end
ORDER BY m.member_id;

-- 2. Сколько людей записано на занятия по датам
SELECT
    v.visit_date,
    COUNT(*) AS visitors_count
FROM visits v
GROUP BY v.visit_date
ORDER BY v.visit_date;

-- 3. Список тренеров и какие у них классы
SELECT
    t.trainer_id,
    t.first_name || ' ' || t.last_name AS trainer_name,
    t.specialization,
    c.class_name,
    c.day_of_week,
    c.start_time,
    c.hall
FROM trainers t
LEFT JOIN classes c ON t.trainer_id = c.trainer_id
ORDER BY t.trainer_id, c.day_of_week;

-- 4. Участники, которые давно не посещали клуб
-- (нет ни одного посещения или последнее было больше 14 дней назад)
SELECT
    m.member_id,
    m.first_name || ' ' || m.last_name AS member_name,
    m.phone,
    m.status,
    MAX(v.visit_date) AS last_visit,
    CASE
        WHEN MAX(v.visit_date) IS NULL THEN 'Никогда не посещал'
        WHEN date('2026-10-03', '-14 days') > MAX(v.visit_date) THEN 'Не был больше 2 недель'
        ELSE 'Был недавно'
    END AS visit_status
FROM members m
LEFT JOIN visits v ON m.member_id = v.member_id
GROUP BY m.member_id
HAVING MAX(v.visit_date) IS NULL
    OR date('2026-10-03', '-14 days') > MAX(v.visit_date)
ORDER BY last_visit;

-- 5. Топ-3 самых популярных занятий
SELECT
    c.class_name,
    t.first_name || ' ' || t.last_name AS trainer_name,
    COUNT(v.visit_id) AS total_visits
FROM classes c
JOIN trainers t ON c.trainer_id = t.trainer_id
LEFT JOIN visits v ON c.class_id = v.class_id
GROUP BY c.class_id
ORDER BY total_visits DESC
LIMIT 3;

-- 6. Сколько клуб заработал по видам абонементов
SELECT
    p.payment_type,
    COUNT(*) AS payments_count,
    SUM(p.amount) AS total_revenue
FROM payments p
GROUP BY p.payment_type
ORDER BY total_revenue DESC;

-- 7. Конфликты в расписании (когда у одного человека пересекаются занятия)
SELECT
    v1.member_id,
    m.first_name || ' ' || m.last_name AS member_name,
    v1.visit_date AS date,
    c1.class_name AS class_1,
    v1.check_in AS start_1,
    v1.check_out AS end_1,
    c2.class_name AS class_2,
    v2.check_in AS start_2,
    v2.check_out AS end_2
FROM visits v1
JOIN visits v2 ON v1.member_id = v2.member_id
    AND v1.visit_id < v2.visit_id
    AND v1.visit_date = v2.visit_date
    AND v1.check_in < v2.check_out
    AND v2.check_in < v1.check_out
JOIN members m ON v1.member_id = m.member_id
JOIN classes c1 ON v1.class_id = c1.class_id
JOIN classes c2 ON v2.class_id = c2.class_id
ORDER BY v1.visit_date, v1.member_id;

-- 8. Загрузка залов (сколько занятий в каждом зале)
SELECT
    c.hall,
    COUNT(*) AS classes_count,
    SUM(c.max_participants) AS total_capacity
FROM classes c
GROUP BY c.hall
ORDER BY classes_count DESC;

-- 9. Средний рейтинг тренеров по специализациям
SELECT
    t.specialization,
    COUNT(*) AS trainers_count,
    ROUND(AVG(t.rating), 2) AS avg_rating
FROM trainers t
GROUP BY t.specialization
ORDER BY avg_rating DESC;

-- 10. Участники без оплаты (нет ни одной записи в payments)
SELECT
    m.member_id,
    m.first_name || ' ' || m.last_name AS member_name,
    m.phone,
    m.membership_type,
    m.status
FROM members m
LEFT JOIN payments p ON m.member_id = p.member_id
WHERE p.payment_id IS NULL
ORDER BY m.member_id;
