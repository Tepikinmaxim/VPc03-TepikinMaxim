PRAGMA foreign_keys = ON;


-- 1. ТРЕНЕРЫ
CREATE TABLE trainers (
  trainer_id     INTEGER PRIMARY KEY,
  first_name     TEXT NOT NULL,
  last_name      TEXT NOT NULL,
  specialization TEXT NOT NULL,
  phone          TEXT,
  hire_date      TEXT NOT NULL CHECK (hire_date <= date('now')),
  rating         REAL DEFAULT 0 CHECK (rating >= 0 AND rating <= 5)
);

-- 2. УЧАСТНИКИ
CREATE TABLE members (
  member_id       INTEGER PRIMARY KEY,
  first_name      TEXT NOT NULL,
  last_name       TEXT NOT NULL,
  phone           TEXT NOT NULL,
  birth_date      TEXT NOT NULL 
    CHECK (birth_date <= date('now', '-14 years')),
  membership_type TEXT NOT NULL,
  join_date       TEXT NOT NULL CHECK (join_date <= date('now')),
  status          TEXT NOT NULL DEFAULT 'active'
    CHECK (status IN ('active', 'frozen', 'cancelled'))
);

-- 3. ЗАНЯТИЯ
CREATE TABLE classes (
  class_id         INTEGER PRIMARY KEY,
  class_name       TEXT NOT NULL,
  trainer_id       INTEGER NOT NULL,
  day_of_week      TEXT NOT NULL,
  start_time       TEXT NOT NULL,
  duration_min     INTEGER NOT NULL CHECK (duration_min BETWEEN 30 AND 180),
  max_participants INTEGER NOT NULL CHECK (max_participants > 0),
  hall             TEXT NOT NULL,
  FOREIGN KEY (trainer_id) REFERENCES trainers(trainer_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
);

-- 4. ПОСЕЩЕНИЯ
CREATE TABLE visits (
  visit_id    INTEGER PRIMARY KEY,
  member_id   INTEGER NOT NULL,
  class_id    INTEGER,
  visit_date  TEXT NOT NULL CHECK (visit_date <= date('now')),
  check_in    TEXT NOT NULL,
  check_out   TEXT,
  CHECK (check_out IS NULL OR check_out > check_in),
  FOREIGN KEY (member_id) REFERENCES members(member_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE,
  FOREIGN KEY (class_id) REFERENCES classes(class_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
);

-- 5. ОПЛАТЫ
CREATE TABLE payments (
  payment_id    INTEGER PRIMARY KEY,
  member_id     INTEGER NOT NULL,
  amount        REAL NOT NULL CHECK (amount > 0),
  payment_date  TEXT NOT NULL CHECK (payment_date <= date('now')),
  payment_type  TEXT NOT NULL,
  period_start  TEXT NOT NULL,
  period_end    TEXT NOT NULL CHECK (period_end >= period_start),
  FOREIGN KEY (member_id) REFERENCES members(member_id)
    ON DELETE RESTRICT
    ON UPDATE CASCADE
);

-- 6. ИНДЕКСЫ
CREATE INDEX IF NOT EXISTS idx_members_phone ON members(phone);
CREATE INDEX IF NOT EXISTS idx_visits_member ON visits(member_id);
CREATE INDEX IF NOT EXISTS idx_visits_class ON visits(class_id);
CREATE INDEX IF NOT EXISTS idx_classes_trainer ON classes(trainer_id);
CREATE INDEX IF NOT EXISTS idx_payments_member ON payments(member_id);


